//
// Created by 陈浩 on 16/7/7.
// Copyright (c) 2016 陈浩. All rights reserved.
//

#import "VideoDecodeOperation.h"
#import <AVFoundation/AVFoundation.h>

@interface VideoDecodeOperation ()

@property (nonatomic, strong) NSString *filePath;
@property (nonatomic, copy) VideoPerDataBlock newVideoFrameBlock;
@property (nonatomic, copy) VideoStopDecodeBlock decodeFinishedBlock;

@end

@implementation VideoDecodeOperation

- (instancetype)initDecoderWithURLPath:(NSString *)path
                 newFrameBlock:(VideoPerDataBlock)newFrameBlock
                 finishedBlock:(VideoStopDecodeBlock)finishedBlock {

    if (self = [super init]) {
        _filePath = path;
        _newVideoFrameBlock = newFrameBlock;
        _decodeFinishedBlock = finishedBlock;
    }
    return self;
}

- (void)main {

    @autoreleasepool {

        if (self.isCancelled) {
            _newVideoFrameBlock = nil;
            _decodeFinishedBlock = nil;
            return;
        }

        AVURLAsset *asset = [AVURLAsset URLAssetWithURL:[[NSURL alloc] initFileURLWithPath:self.filePath] options:nil];
        NSError *error;
        AVAssetReader* reader = [[AVAssetReader alloc] initWithAsset:asset error:&error];
        if (error) {
            return;
        }

        NSArray* videoTracks = [asset tracksWithMediaType:AVMediaTypeVideo];
        AVAssetTrack* videoTrack = [videoTracks objectAtIndex:0];
        // 视频播放时，m_pixelFormatType=kCVPixelFormatType_32BGRA
        // 其他用途，如视频压缩，m_pixelFormatType=kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange
        int m_pixelFormatType = kCVPixelFormatType_32BGRA;
        NSDictionary* options = [NSDictionary dictionaryWithObject:[NSNumber numberWithInt: (int)m_pixelFormatType]
                                                            forKey:(id)kCVPixelBufferPixelFormatTypeKey];
        AVAssetReaderTrackOutput* videoReaderOutput = [[AVAssetReaderTrackOutput alloc]
                initWithTrack:videoTrack outputSettings:options];
        // 使用 AVAssetReader 的addOutput:方法向 AVAssetReader里添加 AVAssetReaderOutput 的具体实现类来读取多媒体(音频/视频)数据
        [reader addOutput:videoReaderOutput];
        [reader startReading];
        // 要确保nominalFrameRate>0，之前出现过android拍的0帧视频
        if (self.isCancelled) {
            _newVideoFrameBlock = nil;
            _decodeFinishedBlock = nil;
            return;
        }

        while ([reader status] == AVAssetReaderStatusReading && videoTrack.nominalFrameRate > 0) {
            if (self.isCancelled) {
                _newVideoFrameBlock = nil;
                _decodeFinishedBlock = nil;
                return;
            }
            /*
             CMSampleBufferRef在Apple官方文档中有专门说明，需要被CFRelease，但需要主要CFRelease的时机，需要在imageBuffer使用完成之后才能释放SampleBuffer，因为在CMSampleBufferGetImageBuffer的Apple文档中有说明，通过此方法获取到的imageBuffer是没有被retain过的，所以如果用户需要持有则需要自己手动retain，通过下面代码可以解决CMSampleBufferRef的清理问题：
             CMSampleBufferRef sampleBuffer = [assetReaderOutput copyNextSampleBuffer];
             */
            
            CMSampleBufferRef sampleBuffer = [videoReaderOutput copyNextSampleBuffer];
            // 为媒体数据设置一个CMSampleBuffer的Core Video图像缓存对象
            CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
            
            // 锁定pixel buffer的基地址
            CVPixelBufferLockBaseAddress(imageBuffer, 0);
            
            // 得到pixel buffer的行字节数
            size_t bytesPerRow = CVPixelBufferGetBytesPerRow(imageBuffer);
            
            // 得到pixel buffer的宽和高
            size_t width = CVPixelBufferGetWidth(imageBuffer);
            size_t height = CVPixelBufferGetHeight(imageBuffer);
            
            //Generate image to edit`
            unsigned char* pixel = (unsigned char *)CVPixelBufferGetBaseAddress(imageBuffer);
            // 创建一个依赖于设备的RGB颜色空间
            CGColorSpaceRef colorSpace=CGColorSpaceCreateDeviceRGB();
            // 用抽样缓存的数据创建一个位图格式的图形上下文（graphics context）对象
            CGContextRef context=CGBitmapContextCreate(pixel, width, height, 8, bytesPerRow, colorSpace,
                                                       kCGBitmapByteOrder32Little|kCGImageAlphaPremultipliedFirst);
            if (context != NULL) {
                // 根据这个位图context中的像素数据创建一个Quartz image对象
                CGImageRef imageRef = CGBitmapContextCreateImage(context);
                // 解锁
                CVPixelBufferUnlockBaseAddress(imageBuffer, 0);
                 // 释放context和颜色空间
                CGColorSpaceRelease(colorSpace);
                CGContextRelease(context);
                
                // 解码图片
                size_t width = CGImageGetWidth(imageRef);
                size_t height = CGImageGetHeight(imageRef);
                size_t bitsPerComponent = CGImageGetBitsPerComponent(imageRef);
                
                // CGImageGetBytesPerRow() calculates incorrectly in iOS 5.0, so defer to CGBitmapContextCreate
                size_t bytesPerRow = 0;
                // 填充颜色
                CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
                // 枚举，填充颜色
                CGColorSpaceModel colorSpaceModel = CGColorSpaceGetModel(colorSpace);
                CGBitmapInfo bitmapInfo = CGImageGetBitmapInfo(imageRef);
                
                if (colorSpaceModel == kCGColorSpaceModelRGB) {
                    uint32_t alpha = (bitmapInfo & kCGBitmapAlphaInfoMask);
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wassign-enum"
                    if (alpha == kCGImageAlphaNone) {
                        bitmapInfo &= ~kCGBitmapAlphaInfoMask;
                        bitmapInfo |= kCGImageAlphaNoneSkipFirst;
                    } else if (!(alpha == kCGImageAlphaNoneSkipFirst || alpha == kCGImageAlphaNoneSkipLast)) {
                        bitmapInfo &= ~kCGBitmapAlphaInfoMask;
                        bitmapInfo |= kCGImageAlphaPremultipliedFirst;
                    }
#pragma clang diagnostic pop
                }
                
                CGContextRef context = CGBitmapContextCreate(NULL, width, height, bitsPerComponent,
                                                             bytesPerRow, colorSpace, bitmapInfo);
                
                CGColorSpaceRelease(colorSpace);
                
                if (!context) {
                    if (self.newVideoFrameBlock) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            if (self.isCancelled) {
                                _newVideoFrameBlock = nil;
                                _decodeFinishedBlock = nil;
                                return;
                            }
                            self.newVideoFrameBlock(imageRef, self.filePath);
                            CGImageRelease(imageRef);
                        });
                    }
                } else {
                    
                    CGContextDrawImage(context, CGRectMake(0.0f, 0.0f, width, height), imageRef);
                    CGImageRef inflatedImageRef = CGBitmapContextCreateImage(context);
                    
                    CGContextRelease(context);
                    if (self.newVideoFrameBlock) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            if (self.isCancelled) {
                                _newVideoFrameBlock = nil;
                                _decodeFinishedBlock = nil;
                                return;
                            }
                            self.newVideoFrameBlock(inflatedImageRef, self.filePath);
                            
                            CGImageRelease(inflatedImageRef);
                        });
                    }
                    CGImageRelease(imageRef);
                }
                
                if(sampleBuffer) {
                    CMSampleBufferInvalidate(sampleBuffer);
                    CFRelease(sampleBuffer);
                    sampleBuffer = NULL;
                    
                } else {
                    break;
                }
            }
            
            [NSThread sleepForTimeInterval:CMTimeGetSeconds(videoTrack.minFrameDuration)];
        }

        if (self.isCancelled) {
            _newVideoFrameBlock = nil;
            _decodeFinishedBlock = nil;
            return;
        }
        if (self.decodeFinishedBlock) {
            self.decodeFinishedBlock(self.filePath);
        }
    }
}

@end