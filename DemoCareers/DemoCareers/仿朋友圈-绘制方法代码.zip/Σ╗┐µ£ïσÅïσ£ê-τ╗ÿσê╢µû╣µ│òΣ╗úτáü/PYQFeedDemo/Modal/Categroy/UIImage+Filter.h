//
//  UIImage+Filter.h
//  UU
//
//  Created by 陈浩 on 16/6/23.
//  Copyright © 2016年 陈浩. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Filter)

- (UIImage *)colorizeImageWithColor:(UIColor *)color;

@end
