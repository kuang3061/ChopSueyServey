# PYQFeedDemo

![][image-2]

[image-2]:	https://cloud.githubusercontent.com/assets/5633917/16712261/506d7242-46b4-11e6-9bad-6b4a5d05c0a5.gif
